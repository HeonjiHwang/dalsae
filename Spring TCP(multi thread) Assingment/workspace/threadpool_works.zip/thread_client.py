import socket
import random, time
import threading
import uuid

def works():
    HOST = 'localhost'
    PORT = 7777
    num = []

    while True:
        sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        sock.connect((HOST,PORT))
        while True:
            serial = uuid.uuid4()
            arr = str(serial).split('-')
            sock.send(arr[0].encode())
            print(serial)
            for i in range(0,30):
                data = round(random.uniform(1,100),2)
                sock.send(str(data).encode())
                num.append(data)
                print(data)
                time.sleep(1)
            wait = random.randint(5,10)
            hi = '-'+ str(wait)
            sock.send(hi.encode())
            num.clear()
            sock.close()
            break



        print('대기시간 :: ',wait)
        time.sleep(wait)


for i in range(0,10):
    thread = threading.Thread(target=works)
    print("\n")
    thread.daemon=True
    thread.start()
