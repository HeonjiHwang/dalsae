package com.example.demo.analysis;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.Repository.collectedRepo;
import com.example.demo.model.collectedModel;
import com.example.demo.shared.SharedData;

//분석 스레드
public class AnalysisWorks implements Runnable{
	private ArrayList<Object> listPop = new ArrayList<Object>();
	private HashMap<Double, String> map;
	
	@Autowired
	private collectedRepo colRepo;
	
	public AnalysisWorks(HashMap<Double, String> map, collectedRepo colRepo) {
		this.map = map;
		this.colRepo = colRepo;
	}
	@Override
	public void run() {
		SharedData.getInstance().getData(listPop);
		
		double sum = 0;
		double avg = 0;
		int count = 0;
		Double max = null;
		Double min = null;
		String maxSerial = null;
		
		for(Object data : listPop) {
			sum+= (Double)data;
			count++;
			if (max == null || max.doubleValue() < (double)data) {
				max = (double)data;
				maxSerial = (String) map.get(max);
			}
			if (min == null || min.doubleValue() > (double)data) {
				min = (double)data;
			}
		}
		
		avg = (count>0)?sum/count:0;
		
		if(avg==0 || min==null || max==null || min.equals(max) || max.equals(avg)) {
			System.out.println("");
		}else {
			System.out.println("min : "+String.format("%.2f", min));
			System.out.println("max : "+max);
			System.out.println("avg : "+String.format("%.2f", avg));
			System.out.println("max serial : "+maxSerial);
			map.clear();
			collectedModel colMod = new collectedModel(maxSerial, avg, max, min);
			colRepo.save(colMod);
		}
		
	}	
}

