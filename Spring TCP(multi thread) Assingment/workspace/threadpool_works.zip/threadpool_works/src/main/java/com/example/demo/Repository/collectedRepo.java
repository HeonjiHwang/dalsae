package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.model.collectedModel;

@Repository
public interface collectedRepo extends JpaRepository<collectedModel, String>{
	@Modifying
	@Query(value="INSERT INTO COLLECTED VALUES (?1,?2,?3,?4)", nativeQuery=true)
	void insert(Double avg, Double max, String meter_serial, Double min);
}
