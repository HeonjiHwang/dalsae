package com.example.demo.connection;

import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.Repository.collectedRepo;
import com.example.demo.analysis.AnalysisWorks;
import com.example.demo.log.Log;
import com.example.demo.shared.SharedData;

public class ConnectionWrap implements Runnable{
	private Socket socket;
	private String serial;
	private long start;
	private static HashMap<Double, String> map = new HashMap<Double,String>();
	private byte[] bytes = new byte[100];
	long diff;
	private String[] wait;
	
	@Autowired
	private collectedRepo colRepo;
	
	public ConnectionWrap(Socket socket, String serial, long start, HashMap<Double, String> map, collectedRepo colRepo) {
		this.socket = socket;
		this.serial = serial;
		this.start = start;
		this.map = map;
		this.colRepo = colRepo;
	}

	@Override
	public void run() {		
		try {
			String threadname = Thread.currentThread().getName();
			System.out.println(threadname);
			while(true) {
				InputStream in = socket.getInputStream();
				int read = in.read(bytes);
				
				if(read==-1){
					Log log = new Log("연결해제", serial, socket.getInetAddress().toString(), socket.getPort());
					System.out.println(log.toString());
					
					/*
					 * client 대기시간사이에 server 60초되면 database저장
					 * */
					int add = (int)diff+Integer.parseInt(wait[1]);
					if(add>60) {
						int x = add-60;
						int y = Integer.parseInt(wait[1])-x;
						for(int i=0;i<y;i++) {
							int sec = (int)diff+i+1;
							System.out.println(sec);
							Thread.sleep(1000);
						}
						AnalysisWorks ay = new AnalysisWorks(map, colRepo);
						ay.run();
						break;
					}else if(add<=60) {
						break;
					}
					
				}
				String num = new String(bytes,0,read);
				
				/*
				 * 대기시간 & 데이터 구분
				 * */
				if(num.contains("-")) {
					wait = num.split("-");						//대기시간
				}else {
					double data = Double.parseDouble(num);		//데이터
					SharedData.getInstance().putData(data);
					map.put(data, serial);
				}
				
				/*
				 * analysis & put data on database
				 * 
				 * */
				long now = System.currentTimeMillis();
				diff = (now-start)/1000 %60+1;
				System.out.println(diff);
				if(diff==60) {
					AnalysisWorks ay = new AnalysisWorks(map, colRepo);
					ay.run();
				}
			}
		}catch(Exception e) {
			try {
				socket.close();
				Log log = new Log("연결해제", serial, socket.getInetAddress().toString(), socket.getPort());
				System.out.println(log.toString());
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
}
