package com.example.demo;

import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.example.demo.Repository.collectedRepo;
import com.example.demo.connection.ConnectionWrap;
import com.example.demo.log.Log;

@SpringBootApplication
@EnableScheduling
public class ThreadpoolWorksApplication implements CommandLineRunner{

	@Autowired
	private collectedRepo colRepo;

	
	private static byte[] bytes = new byte[100];
	private static HashMap<Double, String> map = new HashMap<Double,String>();
	
	public static void main(String[] args) throws Exception {
		
		SpringApplication.run(ThreadpoolWorksApplication.class, args);
	}
	
	@Override
	public void run(String... args) throws Exception {
		ServerSocket server;
		Socket socket;
		ThreadPoolExecutor ex = (ThreadPoolExecutor) Executors.newFixedThreadPool(10);
		try {
			System.out.println("tcp socket start!!!!");
			long start = System.currentTimeMillis();
			server = new ServerSocket();
			server.bind(new InetSocketAddress("localhost",7777));
			while(true) {				
				socket = server.accept();
				try {
					/*
					 * serial
					 * */
					InputStream in = socket.getInputStream();
					int read = in.read(bytes);
					if(read == -1) {
						socket.close();
					}else {
						String serial = new String(bytes,0,read);
						Log log = new Log("연결수락", serial, socket.getInetAddress().toString(), socket.getPort());
						System.out.println(log.toString());
						ex.execute(new ConnectionWrap(socket, serial, start, map, colRepo));
					}
					
				}catch(Exception e) {}
			}
		}catch(Exception e) {}

		
	}
	
}



